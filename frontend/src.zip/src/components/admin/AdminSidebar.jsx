import { NavLink } from "react-router-dom";
import {
  LogOut,
  UserRoundCog,
  ChevronRight,
  Menu,
  LayoutGrid,
  File,
  MessageCircleQuestionMark,
} from "lucide-react";
import char from "../../assets/Favicon_web.svg";
import bar from "../../assets/side_bar.svg";

function AdminSidebar({
  isSidebarOpen,
  setIsSidebarOpen,
  setIsLogoutModal,
  currentView,
  handleViewChange,
  user,
}) {
  const name = user?.name || "";
  const menuItems = [
    {
      view: "dashboard",
      label: "대시보드",
      icon: <LayoutGrid size={18} />,
    },
    { view: "main", label: "계정 관리", icon: <UserRoundCog size={18} /> },

    { view: "documents", label: "문서 관리", icon: <File size={18} /> },
    {
      view: "unanswered",
      label: "미답변 질문",
      icon: <MessageCircleQuestionMark size={18} />,
    },
  ];

  return (
    <div className="contents">
      {isSidebarOpen ? (
        <div
          className="flex flex-col w-[232px] lg:w-[255px] fixed top-0 left-0 h-full z-40 md:relative md:z-10 md:top-auto md:left-auto md:h-auto md:mt-[32px]"
          style={{
            backgroundImage: `url('/chat_bg.png')`,
            backgroundSize: "cover",
            backgroundPosition: "center",
            backgroundAttachment: "fixed",
          }}
        >
          {/* 상단 */}
          <div className="flex items-center justify-between py-[12px] px-[16px]">
            <div className="flex items-center">
              <img
                src={char}
                alt="위드버디 대표 로고"
                className="w-[26px] mr-[12px]"
              />
              <div className="flex gap-[4px] items-center">
                <p className="text-[#343A40] text-[16px] font-semibold">
                  {name}
                </p>
                <p className="py-[2px] px-[8px] rounded-[9999px] bg-[#E6EDF2] text-[11px] text-[#336B97]">
                  관리자
                </p>
              </div>
            </div>
            {/* 데스크탑: bar 아이콘 */}
            <img
              src={bar}
              className="hidden md:block w-[20px] h-[16px] cursor-pointer"
              onClick={() => setIsSidebarOpen(!isSidebarOpen)}
            />
            {/* 모바일: 햄버거 메뉴 */}
            <button
              className="md:hidden"
              onClick={() => setIsSidebarOpen(false)}
            >
              <Menu size={16} />
            </button>
          </div>

          {/* 메뉴 */}
          <div className="flex-1 py-[24px] px-[16px] flex flex-col gap-[8px]">
            {menuItems.map((item) => (
              <button
                key={item.view}
                onClick={() => handleViewChange(item.view)}
                className={`flex items-center justify-between py-[10px] px-[12px] rounded-[6px] border-[1px] w-[200px] lg:w-[231px] h-[48px] lg:h-[46px] hover:bg-[#D0EBFFCC] hover:border-[#D0EBFF] text-[#336B97] text-[16px]
        ${currentView === item.view ? "bg-[#EAF6FF] border-[#4791CA]" : "bg-transparent border-none"}`}
              >
                <div className="flex items-center gap-[10px]">
                  {item.icon}
                  <span>{item.label}</span>
                </div>
                <ChevronRight size={16} />
              </button>
            ))}
          </div>

          {/* 로그아웃 */}
          <button
            className="text-[#204867] mt-auto mb-[36px] flex items-center gap-2 py-[10px] px-[8px] ml-[16px]"
            onClick={() => setIsLogoutModal(true)}
          >
            <LogOut size={14} />
            로그아웃
          </button>
        </div>
      ) : (
        <div className="hidden md:flex relative z-10 w-[76px] flex-col mt-[32px]">
          {/* 상단 */}
          <div className="flex items-center justify-center py-[12px] px-[16px]">
            <img
              src={bar}
              alt="사이드바 토글 아이콘"
              className="w-[20px] h-[16px] cursor-pointer"
              onClick={() => setIsSidebarOpen(!isSidebarOpen)}
            />
          </div>

          {/* 메뉴 */}
          <div className="flex-1 py-[24px] px-[16px] flex flex-col gap-[8px]">
            {menuItems.map((item) => (
              <button
                key={item.view}
                onClick={() => handleViewChange(item.view)}
                className={`flex items-center justify-center py-[10px] px-[12px] rounded-[6px] border-[1px] w-[44px] h-[48px] hover:bg-[#D0EBFFCC] hover:border-[#D0EBFF] text-[#336B97]
        ${currentView === item.view ? "bg-[#EAF6FF] border-[#4791CA]" : "bg-transparent border-none"}`}
              >
                {item.icon}
              </button>
            ))}
          </div>
          {/* 로그아웃 */}
          <button
            className="text-[#204867] mt-auto mb-[36px] flex items-center gap-2 py-[10px] px-[8px] ml-[16px]"
            onClick={() => setIsLogoutModal(true)}
          >
            <LogOut size={14} />
          </button>
        </div>
      )}
    </div>
  );
}

export default AdminSidebar;
