import ReactGA from "react-ga4";

export function trackEvent(eventName, params) {
  ReactGA.event({
    category: eventName.split("_")[0],
    action: eventName,
    ...params,
  });
}
